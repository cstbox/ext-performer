# -*- coding: utf-8 -*-

""" This modules provides a model of discrete event series based on the digital signal
paradigm, for easier correlations and analysis.
"""

from bisect import bisect_left, bisect_right
from datetime import datetime, date

try:
    import arrow
except ImportError:
    arrow = None

__author__ = 'Eric Pascual - CSTB (eric.pascual@cstb.fr)'


def to_milliseconds(ts):
    """ Returns the milliseconds equivalent of a given time stamp.

    If the parameter is a datetime instance, the result is the number of milliseconds elapsed
    from the epoch. The passed datetime is supposed to be naive or UTC.

    If it is provided as an integer, it is just returned as is since supposed to be already converted.

    :param datetime.datetime ts: time stamp
    :return: equivalent milliseconds from Epoch
    :rtype: long
    """
    if isinstance(ts, (int, long, float)):
        return ts
    if isinstance(ts, datetime):
        delta = ts - datetime.utcfromtimestamp(0)
        return long(delta.total_seconds() * 1000)
    if isinstance(ts, date):
        delta = datetime(ts.year, ts.month, ts.day) - datetime.utcfromtimestamp(0)
        return long(delta.total_seconds() * 1000)

    if arrow and isinstance(ts, arrow.Arrow):
        return ts.timestamp * 1000

    raise TypeError('unsupported parameter type')


class Point(object):
    """ A point in a signal.

    A point is composed of a timestamp and a value (real or boolean dependant of the signal).
    For computation efficiency and resources usage optimisation, timestamps are expressed as the
    milliseconds count from Epoch. This has also the advantage to be immune to DST side effects.
    """
    __slots__ = ['_timestamp', '_value']

    def __init__(self, timestamp, value):
        if isinstance(timestamp, datetime):
            timestamp = to_milliseconds(timestamp)
        elif not isinstance(timestamp, (int, long, float)):
            raise TypeError('unsupported timestamp type')

        self._timestamp = timestamp
        self._value = self.cast_value(value)

    @property
    def timestamp(self):
        return self._timestamp

    @property
    def value(self):
        return self._value

    def __repr__(self):
        return "Point(timestamp=%s, value=%s)" % (
            datetime.utcfromtimestamp(self.timestamp / 1000.0),
            self.value
        )

    def __eq__(self, other):
        try:
            return self.timestamp == other.timestamp and self.value == other.value
        except:
            return False

    def __iter__(self):
        # this is used to make our point behave like a tuple
        return iter((self.timestamp, self._value))

    def __getitem__(self, item):
        # this is used to make our point behave like a tuple
        return (self.timestamp, self._value)[item]

    def as_tuple(self):
        return self.timestamp, self._value

    @classmethod
    def cast_value(cls, value):
        return value


class Signal(object):
    """ Root class for signals.

    A signal is mainly a sorted list of timed points, represented by instances of :py:class:`Point`. The class
    adds common operations for easier manipulation.
    """
    point_class = None

    def __init__(self, iterable=None):
        if iterable:
            decorated = sorted((point[0], self.point_class(*point)) for point in iterable)
            self._keys = [k for k, point in decorated]
            self._points = [point for k, point in decorated]
        else:
            self._keys = []
            self._points = []

    def clear(self):
        self.__init__([])

    @property
    def is_empty(self):
        return len(self._points) == 0

    def __len__(self):
        return len(self._points)

    def __getitem__(self, i):
        return self._points[i]

    def __iter__(self):
        return iter(self._points)

    def __reversed__(self):
        return reversed(self._points)

    def __repr__(self):
        return "%s(%r)" % (self.__class__.__name__, self._points)

    def __contains__(self, point):
        return point[0] in self._keys

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self._points == other._points

    def __ne__(self, other):
        return not self.__eq__(other)

    @property
    def points(self):
        return self._points

    def index(self, point):
        return self._keys.index(point[0])

    def add_point(self, timestamp, value, auto_cast=False):
        """ Adds a point to the signal.

        This method takes care of the time line insertion point finding only. The real insert action is
        delegated to concrete sub-classes

        :param timestamp: time position of the transition (msecs absolute time or UTC datetime)
        :param value: new value of the signal (type depends on the signal subclass)
        :param bool auto_cast: it True, the provided value will be casted to the data type of the signal. If False,
        its type will be checked for compatibility, and and exception will be triggered in case of mismatch
        :return: this instance, for chaining purpose
        :rtype: Signal
        """
        if auto_cast:
            value = self.cast_value(value)
        else:
            self._check_value(value)

        timestamp = to_milliseconds(timestamp)
        if self._points:
            # try simple cases first :

            # 1/ new point after the current end of the signal
            wrk_point = self._points[-1]
            if timestamp > wrk_point.timestamp:
                # add the new point only if it changes the current value of the signa
                if value != wrk_point.value:
                    self._append_point(timestamp, value)
                return self

            # 2/ new point before the current start of the signal
            wrk_point = self._points[0]
            if timestamp < wrk_point.timestamp:
                if value != wrk_point.value:
                    # value is different => insert the point
                    self._insert_point(0, timestamp, value)
                else:
                    # value is the same => extend the signal by modifying its original start
                    self._points[0] = self.point_class(timestamp, value)
                    self._keys[0] = timestamp
                return self

            # general case : the insertion point is somewhere in the middle of the signal

            # 1/ find the existing transition immediately before the new one
            i = bisect_left(self._keys, timestamp)

            # 2/ add the point at the found position, applying the appropriate strategy
            # depending on the signal nature
            self._add_point(i, timestamp, value)

        else:
            # the signal was empty => just append the new point
            self._append_point(timestamp, value)

        return self

    def cast_value(self, value):
        """ Casts the provided value to the type matching the real signal type.

        ..important:: must be implemented by concrete classes

        :param value: the input value
        :return: the casted value
        :raises TypeError: if cast cannot be done
        """
        raise NotImplementedError()

    def _check_value(self, value):
        """ This method should be implemented by subclasses to ensure that the value to be added
        matches the type of the signal.

        ..important:: must be implemented by concrete classes

        :param value: the value to be checked
        :raise: ValueError if invalid value
        """
        raise NotImplementedError()

    def _add_point(self, at_index, timestamp, value):
        """ This method does the real job for adding the new point to the signal at a specific position.

        It must be implemented by concrete subclasses to apply the appropriate strategy,
        depending on the nature of the signal.

        :param int at_index: where to insert the new point
        :param long timestamp: point timestamp
        :param value: point value
        """
        raise NotImplementedError()

    def _append_point(self, timestamp, value):
        if not isinstance(timestamp, (int, long)):
            raise ValueError('timestamp type mismatch')
        self._points.append(self.point_class(timestamp, value))
        self._keys.append(timestamp)

    def _insert_point(self, index, timestamp, value):
        if not isinstance(timestamp, (int, long)):
            raise ValueError('timestamp type mismatch')
        self._points.insert(index, self.point_class(timestamp, value))
        self._keys.insert(index, timestamp)

    def get_value_at(self, timestamp):
        """ Returns the value of the signal at a given time.

        :param timestamp: the time (msecs absolute time or UTC datetime)
        :type timestamp: int or datetime
        :return: the signal value
        :raise: ValueError if signal is empty or time before the signal start
        """
        if not self._points:
            raise ValueError('signal is empty')

        timestamp = to_milliseconds(timestamp)
        i = bisect_right(self._keys, timestamp)
        if i:
            # timestamp is after the signal beginning => return the value the last point before
            return self._points[i-1].value
        else:
            # timestamp is before the beginning of the signal => we don't know
            return None

    def start_time(self):
        """ Returns the time of the first signal point
        :return: the msecs absolute time of the first point
        :rtype: int
        :raise: ValueError if signal is empty
        """
        try:
            return self._keys[0]
        except IndexError:
            raise ValueError('signal is empty')

    def start_value(self):
        """ Returns the value of the first signal point
        :raise: ValueError if signal is empty
        """
        try:
            return self._points[0].value
        except IndexError:
            raise ValueError('signal is empty')

    def end_time(self):
        """ Returns the time of the last signal point
        :return: the msecs absolute time of the last point
        :rtype: int
        :raise: ValueError if signal is empty
        """
        try:
            return self._keys[-1]
        except IndexError:
            raise ValueError('signal is empty')

    def end_value(self):
        """ Returns the value of the last signal point
        :raise: ValueError if signal is empty
        """
        try:
            return self._points[-1].value
        except IndexError:
            raise ValueError('signal is empty')

    def get_times(self):
        """ Returns the list of point timestamps.
        :rtype: list of [int]
        """
        return sorted([time for time, value in self._points])

    def get_slice(self, start_time, end_time):
        """ Returns an extract of the signal which points are in the provided time span.
        :param int start_time: lower time bound (msecs absolute time)
        :param int end_time: upper time bound (msecs absolute time)
        :return: the signal comprised in the bounds (copy of the original transitions)
        :raise: ValueError if signal is empty
        """
        if not self._keys:
            raise ValueError('signal is empty')

        start = bisect_left(self._keys, start_time)
        end = bisect_right(self._keys, end_time)
        return self.__class__(self._points[start:end])

    def truncate(self, start_time, end_time):
        """ Truncates the signal by retaining only the transitions are in the provided time span.
        :param int start_time: lower time bound (msecs absolute time or UTC datetime)
        :param int end_time: upper time bound (msecs absolute time or UTC datetime)
        :raise: ValueError if signal is empty
        """
        if not self._keys:
            raise ValueError('signal is empty')

        start_time = to_milliseconds(start_time)
        end_time = to_milliseconds(end_time)

        start = bisect_left(self._keys, start_time)
        end = bisect_right(self._keys, end_time)
        self._points = self._points[start:end]
        self._keys = self._keys[start:end]

    QUANTUM_DAY, QUANTUM_HOUR, QUANTUM_MINUTE = range(3)

    def merge(self, other, keep_our_points=True):
        """ Returns a new signal, composed of the union of both signal points.

        The other signal is supposed to be of the same type as us.

        :param Signal other: the other signal to merge with
        :param bool keep_our_points: it True, our points are kept in favor of other's ones in case
        of conflicting timestamps
        :return: the result of the merge
        :rtype: same as ours
        :raise TypeError: if other signal has not the same type as us
        """
        self_type = type(self)
        if type(other) is not self_type:
            raise TypeError('signal types mismatch')

        if not other:
            return self_type(self.points)

        # initialize the merged signal with the points of the signal which points are candidate for override
        merged = self_type(other.points if keep_our_points else self.points)
