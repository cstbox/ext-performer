# -*- coding: utf-8 -*-

from .analog import AnalogSignal
from .logic import LogicSignal