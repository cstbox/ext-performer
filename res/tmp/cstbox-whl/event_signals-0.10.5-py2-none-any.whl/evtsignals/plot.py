# -*- coding: utf-8 -*-

from datetime import datetime

try:
    import matplotlib
except ImportError:
    matplotlib = None
else:
    import matplotlib.pyplot as plt
    import matplotlib.dates as mdates

import arrow

from evtsignals import LogicSignal

__author__ = 'Eric Pascual - CSTB (eric.pascual@cstb.fr)'


def plot_signals(signals, title=None, signal_labels=None, save_as='/tmp/plot.png', logger=None):
    """
    :param list signals: the list of signals to plot
    :param str title: the plot main title
    :param list signal_labels: the list of signal labels (same sequence as `signals`)
    :param str save_as: path of the graphic file for saving the plot picture
    :param logger: optional logger
    """
    if not matplotlib:
        raise RuntimeError("matplotlib is not installed on this system")

    if not signals:
        raise ValueError('no signal to plot')

    if not isinstance(signals, (list, tuple, set)):
        signals = [signals]

    matplotlib.rcParams.update({'font.size': 8})

    fig, ax = plt.subplots(nrows=len(signals), ncols=1, sharex=True)
    fig.set_size_inches(11, 8)
    # fig.tight_layout()
    if title:
        fig.suptitle(title)

    t_min = arrow.get(2099, 12, 31).timestamp * 1000.
    t_max = 0

    for ndx, sig in enumerate(signals):
        t_min = min(sig.start_time(), t_min)
        t_max = max(sig.end_time(), t_max)

        plot_data = [(mdates.date2num(datetime.utcfromtimestamp(msecs / 1000)), float(v)) for msecs, v in sig.points]
        signal_label = signal_labels[ndx] if signal_labels else None

        if logger:
            if signal_label:
                logger.debug("'%s' plot data=%s", signal_label, plot_data)
            else:
                logger.debug("plot data=%s", plot_data)

        try:
            ax_n = ax[ndx]
        except TypeError:
            # single subplot case handling
            ax_n = ax
            single_subplot = True
        else:
            single_subplot = False

        if isinstance(sig, LogicSignal):
            ax_n.set_ylim(-0.2, 1.2)
            ax_n.step(*zip(*plot_data), where='post')
            ax_n.yaxis.set_ticks([0, 1])
            if signal_labels:
                ax_n.set_ylabel(signal_labels[ndx])

        else:
            ax_n.plot(*zip(*plot_data))
            if signal_label:
                ax_n.set_ylabel(signal_label)
            ax_n.yaxis.grid(True)

        ax_n.xaxis.grid(True)

    t_min = arrow.get(t_min / 1000.)
    t_max = arrow.get(t_max / 1000.)

    if logger:
        logger.debug("t_min=%s tmax=%s", t_min, t_max)

    if t_max.year != t_min.year:
        major_locator = mdates.YearLocator()
        minor_locator = mdates.MonthLocator()
        major_formatter = mdates.DateFormatter("%Y")
        date_min = t_max.floor('month')
        date_max = t_max.ceil('month')
    elif t_max.month != t_min.month:
        major_locator = mdates.MonthLocator()
        minor_locator = mdates.DayLocator(interval=7)
        major_formatter = mdates.DateFormatter("%Y/%m")
        date_min = t_max.floor('month')
        date_max = t_max.ceil('month')
    elif t_max.day != t_min.day:
        major_locator = mdates.DayLocator()
        minor_locator = mdates.HourLocator(interval=6)
        major_formatter = mdates.DateFormatter("%Y/%m/%d")
        date_min = t_max.floor('day')
        date_max = t_max.ceil('day')
    else:
        major_locator = mdates.HourLocator(interval=6)
        minor_locator = mdates.HourLocator()
        major_formatter = mdates.DateFormatter("%d/%m %H:%M")
        date_min = t_max.floor('day')
        date_max = t_max.ceil('day')

    ax_0 = ax if single_subplot else ax[0]
    ax_0.xaxis.set_major_locator(major_locator)
    ax_0.xaxis.set_minor_locator(minor_locator)
    ax_0.xaxis.set_major_formatter(major_formatter)
    ax_0.xaxis_date()
    ax_0.autoscale_view()

    fig.autofmt_xdate()

    if save_as:
        if logger:
            logger.info("plot saved as %s", save_as)
        plt.savefig(save_as, dpi=150)
