# -*- coding: utf-8 -*-
from datetime import datetime, timedelta
from operator import itemgetter
from itertools import islice, izip
from bisect import bisect_left, bisect_right

from .base import Signal, Point, to_milliseconds
from .logic import LogicSignal


class AnalogPoint(Point):
    """ A point carrying an analog (float) value"""
    @classmethod
    def cast_value(cls, value):
        return float(value)


class AnalogSignal(Signal):
    """ Analog signal modeling.

    This class models a timed series of numerical values.
    """
    EXTEND_START, EXTEND_END, EXTEND_BOTH = range(3)

    point_class = AnalogPoint

    def _add_point(self, at_index, timestamp, value):
        left = self._points[at_index - 1]

        if left.timestamp == timestamp:
            self._points[at_index - 1] = AnalogPoint(timestamp, value)

        else:
            self._insert_point(at_index, timestamp, value)

    def cast_value(self, value):
        return AnalogPoint.cast_value(value)

    def _check_value(self, value):
        if not isinstance(value, (int, long, float)):
            raise ValueError("numerical value type mismatch (%s)" % type(value))

    def max(self):
        """ Returns a copy of the point containing the absolute maximum value of the signal.

        :return: max(points)
        :rtype: AnalogPoint
        :raise: ValueError if the signal is empty
        """
        return max(self._points, key=itemgetter(1))

    def min(self):
        """ Returns a copy of the point containing the absolute minimum value of the signal.

        :return: min(points)
        :rtype: AnalogPoint
        :raise: ValueError if the signal is empty
        """
        return min(self._points, key=itemgetter(1))

    def re_sample(self, period, t_start=None, interpolate=False):
        """ Generator producing a periodic signal equivalent to this one by yielding the new points.

        Two strategies are provided for evaluating the intermediate points :

        - last known value (interpolate=False) : applies to aperiodic signals which points represent value changes
            above the signal resolution. The strategy is based on the fact that, given two successive points
            P(t0) and P(t1) in the source signal, P(t) = P(t0) for t0 <= t < t1 because any change of the variable
            produces a new point in its variation signal. Because it requires less computation, this evaluator is
            faster.

        - linear interpolation (interpolate=False) : applies to any kind of signal, and compute intermediate
            values by interpolated successive points

        :param float period: result signal period (in seconds)
        :param t_start: optional starting point of the generated signal. It can be a msecs absolute time or
            and UTC datetime. Defaulted to the start of the source signal
        :param boolean interpolate: if True, compute yje intermediate values using a linear interpolation between
            surrounding points
        :return: the signal points
        :rtype: Point
        :raise ValueError: if the provided start time is not in the time span of the source signal
        """
        if t_start is not None:
            t_start = to_milliseconds(t_start)
            if t_start < self.start_time():
                raise ValueError('start time is before the source signal start')
        else:
            t_start = self.start_time()

        t_end = self.end_time()

        if t_start > t_end:
            raise ValueError('start time is past the source signal end')

        t_out = t_start
        period_msecs = int(period * 1000)
        last_time, last_value = self._points[0]

        def interpolated_value(t):
            return float(v_src - last_value) / (t_src - last_time) * (t - last_time)

        def last_known_value(t):
            return last_value

        value_evaluator = interpolated_value if interpolate else last_known_value

        for t_src, v_src in self._points[1:]:
            while t_out < t_src:
                yield Point(t_out, value_evaluator(t_out))
                t_out += period_msecs
            last_time, last_value = t_src, v_src

        # we cannot interpolate the final point since it is an open segment => stay with the last known value
        yield Point(t_out, last_value)

    def trigger(self, threshold, hysteresis=0):
        """ Produces a logic signal reproducing the output of an analog comparator
        fed with the signal.

        An hysteresis can be set to reduce the noise around the threshold.

        :param float threshold: the comparator reference value
        :param float hysteresis: optional width of the "grey area" centered around the threshold
        :return: the logical signal produced by the comparator
        :rtype: LogicSignal
        """
        output = LogicSignal()

        hysteresis = abs(hysteresis)
        thresh_upper = threshold + hysteresis
        thresh_lower = threshold - hysteresis

        for t, v in self._points:
            if v >= thresh_upper:
                output.add_point(t, True)
            elif v <= thresh_lower:
                output.add_point(t, False)

        return output

    def differentiate(self):
        """ Produces an analog signal which is the time differentiation of the signal.

        ..important:: differentiated values as expressed as "per second"

        :return: the differentiated signal
        :rtype: AnalogSignal
        """
        return AnalogSignal((
            (pt1[0], float(pt1[1] - pt0[1]) / float(pt1[0] - pt0[0]) * 1000.)
            for pt0, pt1 in izip(self._points, islice(self._points, 1, None))
        ))

    def variations(self):
        """ Produces an analog signal which contains the variations between successive points.

        :return: the variations signal
        :rtype: AnalogSignal
        """
        return AnalogSignal((
            (pt1[0], pt1[1] - pt0[1])
            for pt0, pt1 in izip(self._points, islice(self._points, 1, None))
        ))

    def extend(self, time_quantum=Signal.QUANTUM_DAY, directions=EXTEND_END):
        """ Extends the signal so that its ending point is on the requested time quantum.

            The last known value is copied up to the very last instant of the time quantum.

        :param int time_quantum: the time quantum to apply (cf :py:attr:`LogicSignal.QUANTUM_xxx`)
        :param int directions: which direction(s) the extension must be applied
        :raise: ValueError if signal is empty
        """
        if not self._keys:
            raise ValueError('signal is empty')

        if directions in (self.EXTEND_BOTH, self.EXTEND_END):
            last_point = self._points[-1]
            dt = datetime.utcfromtimestamp(last_point.timestamp / 1000.0)
            if time_quantum == Signal.QUANTUM_DAY:
                dt = dt.replace(hour=23, minute=59, second=59, microsecond=999999)
            elif time_quantum == Signal.QUANTUM_HOUR:
                dt = dt.replace(minute=59, second=59, microsecond=999999)
            elif time_quantum == Signal.QUANTUM_MINUTE:
                dt = dt.replace(second=59, microsecond=999999)
            else:
                raise ValueError('invalid time_quantum value')

            self._append_point(to_milliseconds(dt + timedelta(microseconds=1)), last_point.value)

        if directions in (self.EXTEND_BOTH, self.EXTEND_START):
            first_point = self._points[0]
            dt = datetime.utcfromtimestamp(first_point.timestamp / 1000.0)
            if time_quantum == Signal.QUANTUM_DAY:
                dt = dt.replace(hour=0, minute=0, second=0, microsecond=0)
            elif time_quantum == Signal.QUANTUM_HOUR:
                dt = dt.replace(minute=0, second=0, microsecond=0)
            elif time_quantum == Signal.QUANTUM_MINUTE:
                dt = dt.replace(second=0, microsecond=0)
            else:
                raise ValueError('invalid time_quantum value')

            self._insert_point(0, to_milliseconds(dt), first_point.value)

    def get_value_at(self, timestamp, interpolate=False, extrapolate_before=False):
        if not self._points:
            raise ValueError('signal is empty')

        timestamp = to_milliseconds(timestamp)
        i = bisect_right(self._keys, timestamp)
        if i:
            # timestamp is after the signal beginning => get the value the last point before
            last_time, last_known_value = self._points[i-1]
        else:
            # timestamp is before the beginning of the signal
            return self._points[0].value if extrapolate_before else None

        if last_known_value is None or not interpolate:
            return last_known_value

        try:
            next_time, next_value = self._points[i]

        except IndexError:
            # we are after the end of the signal => return the last known value
            return last_known_value

        else:
            return float(next_value - last_known_value) / (next_time - last_time) * (timestamp - last_time)
