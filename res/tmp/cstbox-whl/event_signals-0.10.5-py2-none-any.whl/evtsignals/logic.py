# -*- coding: utf-8 -*-
from datetime import datetime, timedelta

from .base import Signal, Point, to_milliseconds


class LogicPoint(Point):
    """ A point carrying a logical (boolean) value"""
    @classmethod
    def cast_value(cls, value):
        if isinstance(value, basestring):
            return value.lower() in ('true', 't', '1', 'yes', 'y')
        elif isinstance(value, (int, float)):
            return bool(int(value))

        raise ValueError('unable to cast %s to boolean', value)


class LogicSignal(Signal):
    """ Logic signal modeling.

    This class models a timed series of logical states using the logic signal paradigm. Instances store the state
    transitions, from which the signal state can be computed at any time position.

    It also defines basic logical operators (not, and, or), and also more complex ones such as delay, low pass filter,...
    """
    point_class = LogicPoint

    def __init__(self, iterable=None):
        if iterable:
            last_value = None
            reduced = []
            for t, v in iterable:
                if v != last_value:
                    reduced.append((t, v))
                    last_value = v
            super(LogicSignal, self).__init__(reduced)
        else:
            super(LogicSignal, self).__init__(None)

    def _add_point(self, at_index, timestamp, value):
        """ Do the real point insertion job, filtering out points which do not represent a state transition.
        """
        left = self._points[at_index - 1]

        # if the new transition does not change the state, do nothing
        if left.value == value:
            return self

        if left.timestamp != timestamp:
            # most of the time, the new transition is strictly included in left and right ones

            # if here, the value of the new transition is different from the previous transition one, and thus is the
            # same as the next transition one => we replace the next transition by the new one
            self._points[at_index] = LogicPoint(timestamp, value)
            self._keys[at_index] = timestamp

        else:
            # very rare case : the new transition occurs at the same time as the left one
            # => its effect is to cancel both left and right transitions
            del self._points[at_index-1:at_index+1]
            del self._keys[at_index-1:at_index+1]

    def cast_value(self, value):
        return LogicPoint.cast_value(value)

    def _check_value(self, value):
        if not isinstance(value, bool):
            raise ValueError()

    def get_value_at(self, timestamp, **kwargs):
        """ Enhanced version of generic value finding, adding the extrapolation of the signal
        if requesting a value before the starting point.
        """
        value = super(LogicSignal, self).get_value_at(timestamp)
        if value is not None:
            return value

        # if the requested time is before the start point (hence the None value), assume
        # our first point marks a state change and return the resulting extrapolated value
        return not self._points[0].value

    def integrate(self, start=None, end=None):
        """ Integrates the signal between bounds.

        The sum is defined as the elapsed time while the state is high (true). The result is expressed in milliseconds.
        If the signal contains a single point, a constant value is supposed from the point up to the end of the
        integration period.

        Integration bounds must be defined such as start <= end. A ValueError exception is risen otherwise.

        :param start: integration lower bound as an msecs count or an UTC datetime (default: first transition)
        :param end: integration upper bound as an msecs count or an UTC datetime (default: last transition)
        :return: the integration result (as msecs count)
        :rtype: int
        :raise: ValueError in invalid bounds provided
        """
        if start is None:
            start = self.start_time()
        else:
            start = to_milliseconds(start)
        if end is None:
            end = self.end_time()
        else:
            end = to_milliseconds(end)

        if end < start:
            raise ValueError('invalid integration bounds (start=%s end=%s)' % (start, end))

        # eliminate trivial cases

        # - null integration period
        if end == start:
            return 0

        # - single point signal
        if len(self._points) == 1:
            return end - self.start_time() if self.start_value() else 0.

        result = 0
        high_state_start = start if self.get_value_at(start) else None

        for ts, value in self._points:
            if ts < start:
                continue

            if value:
                # in case of duplicated high transitions, keep the older one for integration
                if high_state_start is None:
                    high_state_start = ts
            else:
                if high_state_start is not None:
                    result += min(ts, end) - high_state_start
                    high_state_start = None

            if ts >= end:
                break

        if high_state_start is not None and end > self.end_time():
            result += end - high_state_start

        return result

    def logic_or(self, other):
        """ Computes the output signal of a OR gate fed by this signal and another one.

        ORing with a null or empty signal returns a copy of the instance signal. If self is empty,
        result is a copy of the other.

        :param LogicSignal other: the other signal
        :return: self OR other
        :rtype: LogicSignal
        """
        if not other:
            return LogicSignal(self)
        if not self._points:
            return LogicSignal(other)

        result = LogicSignal()

        self_iter = iter(self)
        self_trans = self_iter.next()

        other_iter = iter(other)
        other_trans = other_iter.next()

        last_state = None
        self_done = other_done = False

        # 1/ process the overlapping parts of the signals
        while not (self_done or other_done):
            self_ts, self_value = self_trans
            other_ts, other_value = other_trans
            if self_ts < other_ts:
                # optimization note: remember that the value of the signal before a transition is supposed to
                # be the inverse of the transition one => use this to avoid calling LogicSignal.get_value_at()
                last_state = _append_if_changed(result, self_ts, self_value or not other_value, last_state)
                self_trans, self_done = _next_transition(self_iter, self_trans)

            elif self_ts > other_ts:
                last_state = _append_if_changed(result, other_ts, other_value or not self_value, last_state)
                other_trans, other_done = _next_transition(other_iter, other_trans)

            else:
                last_state = _append_if_changed(result, other_ts, self_value or other_value, last_state)
                self_trans, self_done = _next_transition(self_iter, self_trans)
                other_trans, other_done = _next_transition(other_iter, other_trans)

        # 2/ append the "tail" of the longest signal
        if self_done:
            it, trans, trailing_value = other_iter, other_trans, self_value
        else:
            it, trans, trailing_value = self_iter, self_trans, other_value

        # optimize processing of remaining values taking in account the truth table of the OR operator
        if trailing_value:
            # trailing state being True, remaining transitions don't really matter since OR result will be True
            # whatever they contain => append only a final transition to True if required
            _append_if_changed(result, trans.timestamp, True, last_state)
        else:
            # trailing state being False, we just have to copy the remaining transitions
            try:
                while True:
                    result._append_point(trans.timestamp, trans.value)
                    trans = it.next()

            except StopIteration:
                pass

        return result

    def logic_and(self, other):
        """ Computes the output signal of a AND gate fed by this signal and another one.

        ANDing with a null or empty signal returns an empty signal.

        :param LogicSignal other: the other signal
        :return: self AND other
        :rtype: LogicSignal
        """
        if not other or not self._points:
            return LogicSignal()

        result = LogicSignal()

        self_iter = iter(self)
        self_trans = self_iter.next()

        other_iter = iter(other)
        other_trans = other_iter.next()

        last_state = None
        self_done = other_done = False

        # 1/ process the overlapping parts of the signals
        while not (self_done or other_done):
            self_ts, self_value = self_trans
            other_ts, other_value = other_trans
            if self_ts < other_ts:
                last_state = _append_if_changed(result, self_ts, self_value and not other_value, last_state)
                self_trans, self_done = _next_transition(self_iter, self_trans)

            elif self_ts > other_ts:
                last_state = _append_if_changed(result, other_ts, other_value and not self_value, last_state)
                other_trans, other_done = _next_transition(other_iter, other_trans)

            else:
                last_state = _append_if_changed(result, other_ts, self_value and other_value, last_state)
                self_trans, self_done = _next_transition(self_iter, self_trans)
                other_trans, other_done = _next_transition(other_iter, other_trans)

        # 2/ append the "tail" of the longest signal
        if self_done:
            it, trans, trailing_value = other_iter, other_trans, self_value
        else:
            it, trans, trailing_value = self_iter, self_trans, other_value

        # optimize processing of remaining values taking in account the truth table of the AND operator
        if trailing_value:
            try:
                while True:
                    result._append_point(trans.timestamp, trans.value)
                    trans = it.next()

            except StopIteration:
                pass
        else:
            # trailing state being False, remaining transitions don't really matter since AND result will be False
            # whatever they contain => append only a final transition to False if required
            _append_if_changed(result, trans.timestamp, False, last_state)

        return result

    def logic_not(self):
        """ Returns the invert of the signal.

        :return: NOT self
        :rtype: LogicSignal
        """
        if not self._points:
            return LogicSignal()

        result = LogicSignal()

        for trans in self:
            result._append_point(trans.timestamp, not trans.value)

        return result

    def invert(self):
        """ Inverts the signal in place.
        """
        for i, trans in enumerate(self):
            self._points[i] = LogicPoint(trans.timestamp, not trans.value)

    def lpf(self, min_duration):
        """ Returns the signals without pulses shorter than a given duration.

        The signal must contains at least 2 transitions to be filtered, otherwise a ValueError exception
        is raised.

        :param int min_duration: pulse duration threshold (msecs)
        :return: the filtered signal
        :rtype: LogicSignal
        :raise: ValueError if signal does not contains enough transitions to be filtered, or if tmin parameter is
        negative or null.
        """
        if min_duration <= 0:
            raise ValueError('invalid filtering threshold')

        if len(self) < 2:
            raise ValueError('signal does not contain enough transitions')

        result = LogicSignal()

        it = iter(self)
        candidate = it.next()
        try:
            while True:
                trans = it.next()
                if candidate:
                    if trans.timestamp - candidate.timestamp >= min_duration:
                        result._append_point(candidate.timestamp, candidate.value)
                        candidate = trans
                    else:
                        candidate = None
                else:
                    candidate = trans

        except StopIteration:
            result._append_point(candidate.timestamp, candidate.value)

        return result

    EDGE_RAISING, EDGE_FALLING, EDGE_BOTH = range(3)

    def delay(self, duration, trigger, restartable):
        """ Creates a new signal equals to the output of a mono-stable gate triggered by this signal.

        :param int duration: delay duration in msecs
        :param int trigger: triggered signal edge selectors (LogicSignal.EDGE_xxx)
        :param boolean restartable: if True a trigger while output is True reset the delay
        :return: delayed signal
        :rtype: LogicSignal
        """
        if duration <= 0:
            raise ValueError('invalid duration')
        if trigger == LogicSignal.EDGE_RAISING:
            trigger_values = [True]
        elif trigger == LogicSignal.EDGE_FALLING:
            trigger_values = [False]
        elif trigger == LogicSignal.EDGE_BOTH:
            trigger_values = [False, True]
        else:
            raise ValueError('invalid edge selector')

        result = LogicSignal()

        pulse_start = None
        for trans in self:
            if pulse_start is not None and trans.timestamp - pulse_start > duration:
                result._append_point(pulse_start + duration, False)
                pulse_start = None

            if trans.value in trigger_values:
                if pulse_start:
                    if restartable:
                        pulse_start = trans.timestamp
                else:
                    result._append_point(trans.timestamp, True)
                    pulse_start = trans.timestamp

        if pulse_start:
            result._append_point(pulse_start + duration, False)

        return result

    def shift(self, delay):
        """ Returns the signal shifted by a given amount amount of msecs.

        :param int delay: shift delay (msecs)
        :return: the shifted signal
        """
        result = LogicSignal()
        for trans in self:
            result._append_point(trans.timestamp + delay, trans.value)
        return result

    def edge_count(self, edge_type):
        """ Returns the count of edges of the requested type
        :param int edge_type: edge type (LogicSignal.EDGE_xxx)
        :return: count
        :rtype: int
        """
        if edge_type == LogicSignal.EDGE_BOTH:
            return len(self)
        if edge_type == LogicSignal.EDGE_RAISING:
            return len([t for t in self._points if t.value])
        if edge_type == LogicSignal.EDGE_FALLING:
            return len([t for t in self._points if not t.value])
        raise ValueError('invalid edge selector')

    def pprint(self):
        import pprint
        pprint.pprint(self._points)

    def quantize_bounds(self, quantize_start=True, quantize_end=True, time_quantum=Signal.QUANTUM_DAY):
        """ Extends the signal so that its endings transitions are on the requested time quantum.

        The following rules are applied :

        1/ start quantization:
            The state of the signal before the first known transition is set to the inverse of the transition state.
            A transition to this state is inserted at the very beginning of the requested time quantum.

        2/ end quantization:
            The last known state is extended up to the very last instant of the time quantum by created an inverse
            transition located at the next time unit. This transition is thus not included in the period.

        :param boolean quantize_start: True (default) to extend the signal in the past
        :param boolean quantize_end: : True (default) to extend the signal in the future
        :param int time_quantum: the time quantum to apply (cf :py:attr:`LogicSignal.QUANTUM_xxx`)
        :raise: ValueError if signal is empty
        """
        if not self._keys:
            raise ValueError('signal is empty')

        if quantize_start:
            # extension of the signal start state is done by inserting a transition at the corresponding time,
            # which value is the inverse of the first transition
            trans = self._points[0]
            dt = datetime.utcfromtimestamp(trans.timestamp / 1000.0)
            if time_quantum == self.QUANTUM_DAY:
                dt = dt.replace(hour=0, minute=0, second=0, microsecond=0)
            elif time_quantum == self.QUANTUM_HOUR:
                dt = dt.replace(minute=0, second=0, microsecond=0)
            elif time_quantum == self.QUANTUM_MINUTE:
                dt = dt.replace(second=0, microsecond=0)
            else:
                raise ValueError('invalid time_quantum value')

            self._insert_point(0, to_milliseconds(dt), not trans.value)

        if quantize_end:
            # extension of the signal end state is done by appending a reverse transition at the next time unit.
            trans = self._points[-1]
            dt = datetime.utcfromtimestamp(trans.timestamp / 1000.0)
            if time_quantum == Signal.QUANTUM_DAY:
                dt = dt.replace(hour=23, minute=59, second=59, microsecond=999999)
            elif time_quantum == Signal.QUANTUM_HOUR:
                dt = dt.replace(minute=59, second=59, microsecond=999999)
            elif time_quantum == Signal.QUANTUM_MINUTE:
                dt = dt.replace(second=59, microsecond=999999)
            else:
                raise ValueError('invalid time_quantum value')

            self._append_point(to_milliseconds(dt + timedelta(microseconds=1)), not trans.value)


def _append_if_changed(signal, ts, value, last):
    if value != last:
        signal._append_point(ts, value)
        last = value
    return last


def _next_transition(sig_iter, trans):
    try:
        trans = sig_iter.next()
        return trans, False
    except StopIteration:
        return trans, True